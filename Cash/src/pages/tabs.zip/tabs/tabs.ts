import { Component } from '@angular/core';

import { MinePage } from '../mine/mine';
import { HomePage } from '../home/home';
import {AboutPage} from '../about/about'

@Component({
  templateUrl: 'tabs.html'
})
export class TabsPage {
public isShow=false
  tab1Root = HomePage;
  tab2Root = AboutPage;
  tab3Root = MinePage;

  constructor() {

  }

  show(){
    // alert('add')
  }
}
